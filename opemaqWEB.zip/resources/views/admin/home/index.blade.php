@extends('adminlte::page')

@section('title', 'Home')

@section('content_header')
    <img style="margin-left: 25%;" src="https://valederans.com/wp-content/uploads/2014/02/construcao.png" alt="página em contrução" >
@stop

@section('content')
@stop