<?php $__env->startSection('title', 'Conjuntos Mecanizados'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Conjuntos Mecanizados</h1>

    <ol class="breadcrumb">
        <li><a href="/">
            <i class="fa fa-home"></i>            
            Inicio
        </a></li>
        <li><a href="">Conjuntos Mecanizados</a></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-danger">
          <div class="box-header">
            <a href="<?php echo e(route('conjuntos.cadastrar')); ?>" class="btn btn-primary">
                <i class="fa fa-plus-circle"></i>
                Novo Conjunto Mecanizado
            </a>

            <div class="box-tools">
              <div class="input-group input-group-sm" style="width: 150px;">
                <input type="text" name="table_search" class="form-control pull-right" placeholder="Pesquisar">

                <div class="input-group-btn">
                  <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                </div>
              </div>
            </div>
          </div>
          <!-- /.box-header -->
          <div class="box-body table-responsive no-padding">
            <?php echo $__env->make('admin.includes.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <table class="table table-hover">
              <tbody>
                <tr>
                    <th>Apelido</th>
                    <th>Trator</th>
                    <th>Implemento</th>
                    <th>Ações</th>
                </tr>
                
                <?php $__currentLoopData = $conjuntos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conjunto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                    <tr>
                        <td><?php echo e($conjunto->apelido); ?></td>
                        <td><?php echo e($conjunto->trator); ?></td>
                        <td><?php echo e($conjunto->implemento); ?></td>
                        <td>
                            <a href='<?php echo e(route('conjuntos.excluirView', ['id'=>$conjunto->id])); ?>' class="btn btn-xs btn-danger btn-action" title="Excluir">
                                <i class="fa fa-trash"></i>                   
                            </a>
                            <a href='<?php echo e(route('conjuntos.editarView', ['id'=>$conjunto->id])); ?>' class="btn btn-xs btn-primary btn-action" title="Editar">
                                <i class="fa fa-pencil"></i>                 
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>