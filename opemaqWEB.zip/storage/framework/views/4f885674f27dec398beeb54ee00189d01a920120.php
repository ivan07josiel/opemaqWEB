<?php $__env->startSection('title', 'Editar Funcionário'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar Funcionário</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="col-md-12 ">
    <div class="box box-danger">
        <div class="box-header with-border">
            <h3>Dados do Funcionário</h3>
        </div>
        <form id="formFunc" action=" <?php echo e(route('funcionarios.update')); ?> " method="POST" > 
            <?php echo e(csrf_field()); ?>   
            <input type="hidden" name="id" value="<?php echo e($funcionario->id); ?>">
            <div class="box-body">
                    <div class="row">
                        <div class="form-group col-md-6 <?php echo e($errors->has('nome') ? 'has-error' : ''); ?>">
                            <label for="nome">Nome Completo*</label>
                            <input type="text" class="form-control input-lg " value="<?php echo e($funcionario->nome); ?>" id="nome" name="nome" placeholder="Nome do funcionário">
                            <?php if($errors->has('nome')): ?>
                                <span class="help-block invalid-feedback">
                                    <?php echo e($errors->first()); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="dataAdmissao">Data de admissão*</label>
                            <input type="date" class="form-control input-lg" value="<?php echo e($funcionario->data_admissao); ?>" id="dataAdmissao" name="data_admissao">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="dataNascimento">Data de nascimento*</label>
                            <input type="date" class="form-control input-lg" value="<?php echo e($funcionario->data_nascimento); ?>" id="dataNascimento" name="data_nascimento">
                        </div>
                    </div>
                    
                    <div class="row">
                        
                        <div class="form-group col-md-3">
                            <label for="fgts">FGTS</label>
                            <input type="text" class="form-control input-lg" value="<?php echo e($funcionario->fgts); ?>" id="fgts" name="fgts" placeholder="Insira o FGTS">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="insalubridade">Insalubridade</label>
                            <input type="text" class="form-control input-lg" value="<?php echo e($funcionario->insalubridade); ?>" id="insalubridade" name="insalubridade" placeholder="Digite o valor">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="periculosidade">Periculosidade</label>
                            <input type="text" class="form-control input-lg" value="<?php echo e($funcionario->periculosidade); ?>" id="periculosidade" name="periculosidade" placeholder="Nível de periculosidade">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="inss">INSS</label>
                            <input type="text" class="form-control input-lg" value="<?php echo e($funcionario->inss); ?>" id="inss" name="inss" placeholder="Digite o número de INSS">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="form-group col-md-3">
                            <label for="agua">Água</label>
                            <input type="text" class="form-control input-lg" value="<?php echo e($funcionario->agua); ?>" id="agua" name="agua" placeholder="Digite o valor">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="luz">Luz</label>
                            <input type="text" class="form-control input-lg" value="<?php echo e($funcionario->luz); ?>" id="luz" name="luz" placeholder="Digite o valor">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="aluguel">Aluguel</label>
                            <input type="text" class="form-control input-lg" value="<?php echo e($funcionario->aluguel); ?>" id="aluguel" name="aluguel" placeholder="Digite o valor">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="encargos">Encargos</label>
                            <input type="text" class="form-control input-lg" value="<?php echo e($funcionario->encargos); ?>" id="encargos" name="encargos" placeholder="Digite o valor">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="form-group col-md-3">
                            <label for="funcao">Função</label>
                            <select name="funcao" class="form-control input-lg">
                                <?php $__currentLoopData = $funcoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funcao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($funcao->id); ?>" <?php echo e($funcao->id == $funcionario->funcao ? 'selected' : ''); ?> > <?php echo e($funcao->nome); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group col-md-3">
                            <label for="encargos">Salário</label>
                            <input type="number" class="form-control input-lg" value="<?php echo e($funcionario->salario); ?>" id="salario" name="salario" placeholder="Digite o valor">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="experiencia">Experiência</label>
                            <textarea type="text" id="experiencia" name="experiencia" class="md-textarea form-control input-lg" rows="3"><?php echo e($funcionario->experiencia); ?></textarea>
                        </div>
                    </div>
            </div> <!-- box-body -->

            <!-- Botoes -->
            <div class="box-footer">
                <a href=" <?php echo e(route('funcionarios.index')); ?> " id="btn_voltar" class="btn btn-danger btn-lg">
                        <i class="fa fa-angle-left fa-lg"></i>          
                        &nbsp;Cancelar
                </a>
                <button type="submit" id="btn_salvar" class="btn btn-lg btn-primary">
                        <i class="fa fa-save fa-lg"></i>          
                        &nbsp;Salvar
                </button>    
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>