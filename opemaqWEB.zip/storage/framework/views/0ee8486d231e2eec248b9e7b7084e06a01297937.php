<?php $__env->startSection('title', 'Editar Propriedade'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar Propriedade</h1>

    <ol class="breadcrumb">
        <li><a href="/">
            <i class="fa fa-home"></i>            
            Inicio
        </a></li>
        <li><a href=" <?php echo e(route('propriedades.index')); ?> ">Propriedades</a></li>
        <li><a href="">Editar</a></li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-12 ">
    <div class="box box-danger">
        <div class="box-header with-border">
            <h3>Dados da propriedade</h3>
        </div>
        <form id="formFunc" action=" <?php echo e(route('propriedades.update')); ?> " method="POST" > 
            <?php echo e(csrf_field()); ?>   
            <input type="hidden" name="id" value="<?php echo e($propriedade->id); ?>">
            <div class="box-body">
                <div class="row">
                    <div class="form-group col-md-6 <?php echo e($errors->has('nome') ? 'has-error' : ''); ?>">
                        <label for="nome">Nome*</label>
                        <input type="text" class="form-control input-lg " value="<?php echo e($propriedade->nome); ?>" id="nome" name="nome" placeholder="Nome da propriedade">
                        <?php if($errors->has('nome')): ?>
                            <span class="help-block invalid-feedback">
                                <?php echo e($errors->first()); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-md-3 <?php echo e($errors->has('data') ? 'has-error' : ''); ?>">
                        <label for="data">Data*</label>
                        <input type="date" class="form-control input-lg " value="<?php echo e($propriedade->data); ?>" id="data" name="data">
                        <?php if($errors->has('data')): ?>
                            <span class="help-block invalid-feedback">
                                <?php echo e($errors->first()); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-md-3 <?php echo e($errors->has('valor') ? 'has-error' : ''); ?>">
                        <label for="valor">Valor</label>
                        <input type="number" class="form-control input-lg " value="<?php echo e($propriedade->valor); ?>" id="valor" name="valor">
                        <?php if($errors->has('valor')): ?>
                            <span class="help-block invalid-feedback">
                                <?php echo e($errors->first()); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="row">
                    
                    <div class="form-group col-md-3 <?php echo e($errors->has('tamanho') ? 'has-error' : ''); ?>">
                        <label for="tamanho">Tamaho da propriedade</label>
                        <input type="text" class="form-control input-lg " value="<?php echo e($propriedade->tamanho); ?>" id="tamanho" name="tamanho" placeholder="Insira o tamanho">
                        <?php if($errors->has('tamanho')): ?>
                            <span class="help-block invalid-feedback">
                                <?php echo e($errors->first()); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-md-3 <?php echo e($errors->has('percuso_manobra') ? 'has-error' : ''); ?>">
                        <label for="percuso_manobra">Percuso e manobra</label>
                        <select class="form-control input-lg " value="<?php echo e($propriedade->percuso_manobra); ?>" name="percuso_manobra" id="percurso_manobra">
                            <option value="1" <?php echo e($propriedade->percurso_manobra == 1 ? 'selected' : ''); ?> >1</option>
                            <option value="2" <?php echo e($propriedade->percurso_manobra == 2 ? 'selected' : ''); ?>>2</option>
                            <option value="3" <?php echo e($propriedade->percurso_manobra == 3 ? 'selected' : ''); ?>>3</option>
                            <option value="4" <?php echo e($propriedade->percurso_manobra == 4 ? 'selected' : ''); ?>>4</option>
                        </select>
                        <small class="text-muted form-text" id="percursoManobra" style="padding: 7px;">Tipo de percurso e manobra varia de 1 a 4</small>
                        <?php if($errors->has('percuso_manobra')): ?>
                            <span class="help-block invalid-feedback">
                                <?php echo e($errors->first()); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-md-3 <?php echo e($errors->has('relevo') ? 'has-error' : ''); ?>">
                        <label for="relevo">Relevo</label>
                        <select name="relevo" class="form-control input-lg " id="relevo">
                            <option	disabled selected>Selecione	o relevo</option>
                            <option	value="plano" <?php echo e($propriedade->relevo == 'plano' ? 'selected' : ''); ?>>Plano</option>
                            <option	value="suave" <?php echo e($propriedade->relevo == 'suave' ? 'selected' : ''); ?>>Suave ondulado</option>
                            <option value="ondulado" <?php echo e($propriedade->relevo == 'ondulado' ? 'selected' : ''); ?>>Ondulado</option>
                            <option	value="forteOndulado" <?php echo e($propriedade->relevo == 'forteOndulado' ? 'selected' : ''); ?>>Forte ondulado</option>
                            <option value="montanhoso" <?php echo e($propriedade->relevo == 'montanhoso' ? 'selected' : ''); ?>>Montanhoso</option>
                            <option	value="escarpa" <?php echo e($propriedade->relevo == 'escarpa' ? 'selected' : ''); ?>>Escarpa</option>
                        </select>
                        <?php if($errors->has('relevo')): ?>
                            <span class="help-block invalid-feedback">
                                <?php echo e($errors->first()); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-md-3 <?php echo e($errors->has('solo') ? 'has-error' : ''); ?>">
                        <label for="solo">Solo</label>
                        <select name="solo" class="form-control input-lg " id="solo">
                            <option	disabled selected>Selecione	o solo</option>
                            <option	value="arenoso" <?php echo e($propriedade->solo == 'arenoso' ? 'selected' : ''); ?>>Arenoso</option>
                            <option	value="argiloso" <?php echo e($propriedade->solo == 'argiloso' ? 'selected' : ''); ?>>Argiloso</option>
                            <option	value="arenoArg" <?php echo e($propriedade->solo == 'arenoArg' ? 'selected' : ''); ?>>Areno Argiloso</option>
                            <option value="siltoso" <?php echo e($propriedade->solo == 'siltoso' ? 'selected' : ''); ?>>Siltoso</option>
                            <option value="outro" <?php echo e($propriedade->solo == 'outro' ? 'selected' : ''); ?>>Outro</option>
                        </select>
                        <?php if($errors->has('solo')): ?>
                            <span class="help-block invalid-feedback">
                                <?php echo e($errors->first()); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="row">
                    <div class="form-group col-md-3 <?php echo e($errors->has('declividade') ? 'has-error' : ''); ?>">
                        <label for="declividade">Declividade</label>
                        <select name="declividade" class="form-control input-lg " id="declividade">
                            <option	disabled selected>Selecione	a declividade</option>
                            <option	value="0-3" <?php echo e($propriedade->declividade == '0-3' ? 'selected' : ''); ?>>0 - 3%</option>
                            <option	value="3-8" <?php echo e($propriedade->declividade == '3-8' ? 'selected' : ''); ?>>3 - 8%</option>
                            <option value="8-13" <?php echo e($propriedade->declividade == '8-13' ? 'selected' : ''); ?>>8 - 13%</option>
                            <option	value="13-20" <?php echo e($propriedade->declividade == '13-20' ? 'selected' : ''); ?>>13 - 20%</option>
                            <option value="20-45" <?php echo e($propriedade->declividade == '20-45' ? 'selected' : ''); ?>>20 - 45%</option>
                            <option	value="45-100" <?php echo e($propriedade->declividade == '45-100' ? 'selected' : ''); ?>>45 - 100%</option>
                            <option	value=">100" <?php echo e($propriedade->declividade == '>100' ? 'selected' : ''); ?>>Maior que 100%</option>
                        </select>
                        <?php if($errors->has('declividade')): ?>
                            <span class="help-block invalid-feedback">
                                <?php echo e($errors->first()); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-md-3 <?php echo e($errors->has('fertilidade') ? 'has-error' : ''); ?>">
                        <label for="fertilidade">Fertilidade</label>
                        <select name="fertilidade" class="form-control input-lg " id="fertilidade">
                            <option	disabled selected>Nível de fertilidade</option>
                            <option	value="baixa" <?php echo e($propriedade->fertilidade == 'baixa' ? 'selected' : ''); ?>>Baixa</option>
                            <option	value="media" <?php echo e($propriedade->fertilidade == 'media' ? 'selected' : ''); ?>>Média</option>
                            <option value="alta" <?php echo e($propriedade->fertilidade == 'alta' ? 'selected' : ''); ?>>Alta</option>
                        </select>
                        <?php if($errors->has('fertilidade')): ?>
                            <span class="help-block invalid-feedback">
                                <?php echo e($errors->first()); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div> <!-- box-body -->

            <!-- Botoes -->
            <div class="box-footer">
                <a href=" <?php echo e(route('propriedades.index')); ?> " id="btn_voltar" class="btn btn-danger btn-lg">
                        <i class="fa fa-angle-left fa-lg"></i>          
                        &nbsp;Cancelar
                </a>
                <button type="submit" id="btn_salvar" class="btn btn-lg btn-primary">
                        <i class="fa fa-save fa-lg"></i>          
                        &nbsp;Salvar
                </button>    
            </div>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>