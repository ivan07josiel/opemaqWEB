<?php $__env->startSection('title', 'Remover Trator/Implemento'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Remover <?php echo e($trator->etrator ? 'Trator' : 'Implemento'); ?></h1>

    <ol class="breadcrumb">
        <li><a href="/">
            <i class="fa fa-home"></i>            
            Inicio
        </a></li>
        <li><a href="<?php echo e(route('tratores.index')); ?>">Tratores e Implementos</a></li>
        <li><a href="">Remover</a></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-5">
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h3>Deseja excluir esse <?php echo e($trator->etrator ? 'Trator' : 'Implemento'); ?>?</h3>
                </div>
                <div class="box-body">
                    <div class="text-right">
                        <a href='<?php echo e(route('tratores.index')); ?>' class="btn btn-primary btn-action border">
                            <i class="fa fa-angle-left fa-lg"></i>          
                            &nbsp;Cancelar             
                        </a>
                        <a href='<?php echo e(route('tratores.delete', ['id'=>$trator->id])); ?>' class="btn btn-danger btn-action">
                            <i class="fa fa-times fa-lg"></i>          
                            &nbsp;Excluir   
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h3><?php echo e($trator->etrator ? 'Trator' : 'Implemento'); ?></h3>
                </div>
                <div class="box-body">
                    <div>
                        <h4>Apelido: <?php echo e($trator->apelido); ?> </h4>
                        <h4>Marca: <?php echo e($trator->marca); ?> </h4>
                        <h4>Ano: <?php echo e($trator->ano); ?> </h4>
                        <h4>Cor: <?php echo e($trator->cor); ?> </h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>