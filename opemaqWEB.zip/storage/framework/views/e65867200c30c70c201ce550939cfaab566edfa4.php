<?php $__env->startSection('title', 'Remover Conjunto'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Remover Conjunto Mecanizado</h1>

    <ol class="breadcrumb">
        <li><a href="/">
            <i class="fa fa-home"></i>            
            Inicio
        </a></li>
        <li><a href="<?php echo e(route('conjuntos.index')); ?>">Conjuntos Mecanizados</a></li>
        <li><a href="">Remover</a></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-5">
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h3>Deseja excluir esse Conjunto Mecanizado?</h3>
                </div>
                <div class="box-body">
                    <div class="text-right">
                        <a href='<?php echo e(route('conjuntos.index')); ?>' class="btn btn-primary btn-action border">
                            <i class="fa fa-angle-left fa-lg"></i>          
                            &nbsp;Cancelar             
                        </a>
                        <a href='<?php echo e(route('conjuntos.delete', ['id'=>$conjunto->id])); ?>' class="btn btn-danger btn-action">
                            <i class="fa fa-times fa-lg"></i>          
                            &nbsp;Excluir   
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h3>Conjunto Mecanizado</h3>
                </div>
                <div class="box-body">
                    <div>
                        <h4>Apelido: <?php echo e($conjunto->apelido); ?> </h4>
                        <h4>Trator: <?php echo e($conjunto->trator); ?> </h4>
                        <h4>Implemento: <?php echo e($conjunto->implemento); ?> </h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>