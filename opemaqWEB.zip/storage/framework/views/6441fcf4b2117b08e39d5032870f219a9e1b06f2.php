<?php $__env->startSection('title', 'Remover Planejamento'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Remover Planejamento</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-5">
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h3>Deseja excluir esse planejamento?</h3>
                </div>
                <div class="box-body">
                    <div class="text-right">
                        <a href='<?php echo e(route('planejamento.index')); ?>' class="btn btn-primary btn-action border">
                            <i class="fa fa-angle-left fa-lg"></i>          
                            &nbsp;Cancelar             
                        </a>
                        <a href='<?php echo e(route('planejamento.delete', ['id'=>$planejamento->id])); ?>' class="btn btn-danger btn-action">
                            <i class="fa fa-times fa-lg"></i>          
                            &nbsp;Excluir   
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h3>Planejamento</h3>
                </div>
                <div class="box-body">
                    <div>
                        <h4>Nome: <?php echo e($planejamento->nome); ?> </h4>
                        <h4>Operação: <?php echo e($operacao->nome); ?> </h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>