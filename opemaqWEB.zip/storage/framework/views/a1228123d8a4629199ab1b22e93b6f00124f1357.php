<?php $__env->startSection('css'); ?>
    <style>
    .select2-selection--multiple {
        min-height: 45px !important;
        text-align: center;
    }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Cadastro Conjunto Mecanizado'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Novo Conjunto Mecanizado</h1>

    <ol class="breadcrumb">
        <li><a href="/">
            <i class="fa fa-home"></i>            
            Inicio
        </a></li>
        <li><a href=" <?php echo e(route('conjuntos.index')); ?> ">Tratores e Implementos</a></li>
        <li><a href="">Cadastrar</a></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 ">
        <div class="box box-danger">
            <div class="box-header with-border">
                <h3>Dados Cadastrais</h3>
            </div>
            <form id="formFunc" action=" <?php echo e(route('conjuntos.store')); ?> " method="POST" > 
                <?php echo e(csrf_field()); ?>   
                <div class="box-body">
                    <div class="row">
                        <div class="form-group col-md-4 <?php echo e($errors->has('apelido') ? 'has-error' : ''); ?>">
                            <label for="apelido">Apelido*</label>
                            <input type="text" class="form-control input-lg " id="apelido" name="apelido" placeholder="Nome do Conjunto Mecanizado">
                            <?php if($errors->has('apelido')): ?>
                                <span class="help-block invalid-feedback">
                                    <?php echo e($errors->first()); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Funcionários</label>
                            <select name="funcionarios[]" class="form-control select2" multiple="" data-placeholder="Selecione o(s) funcionário(s)" style="width: 100%; height: 100%;">
                                <?php $__currentLoopData = $funcionarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funcionario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($funcionario->id); ?>"><?php echo e($funcionario->nome); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="trator">Implemento</label>
                            <select name="id_trator" id="trator" class="form-control input-lg">
                                <?php $__currentLoopData = $tratores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($trator->id); ?>"> <?php echo e($trator->apelido); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="implemento">Implemento</label>
                            <select name="id_implemento" id="implemento" class="form-control input-lg">
                                <?php $__currentLoopData = $implementos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $implemento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($implemento->id); ?>"> <?php echo e($implemento->apelido); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div> <!-- box-body -->

                <!-- Botoes -->
                <div class="box-footer text-right">
                    <button type="submit" id="btn_cadastrar" class="btn btn-lg btn-primary">
                            <i class="fa fa-save"></i>          
                            &nbsp;Cadastrar
                    </button>    
                    <a href=" <?php echo e(route('conjuntos.index')); ?> " id="btn_voltar" class="btn btn-danger btn-lg">
                        <i class="fa fa-undo"></i>          
                        &nbsp;Voltar
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $('.select2').select2();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>