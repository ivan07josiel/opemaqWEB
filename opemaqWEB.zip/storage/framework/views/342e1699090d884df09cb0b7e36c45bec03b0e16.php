<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content_header'); ?>
    <img style="margin-left: 25%;" src="https://valederans.com/wp-content/uploads/2014/02/construcao.png" alt="página em contrução" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>